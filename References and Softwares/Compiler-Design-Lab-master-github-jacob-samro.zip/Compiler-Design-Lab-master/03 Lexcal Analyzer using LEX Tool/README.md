Steps to compile
```
lex lex.l
gcc lex.yy.c
./a.out input.c
```
