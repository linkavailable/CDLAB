### Steps to compile

#### Compiling the Stack Program

```
gcc stack.c
./a.out
```

#### Compiling the Storage Allocation Program
```
gcc storage_allocation.c
./a.out
```
