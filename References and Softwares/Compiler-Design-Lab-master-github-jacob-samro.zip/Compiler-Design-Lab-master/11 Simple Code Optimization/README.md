Steps to compile

```
gcc program.c
./a..out
```
