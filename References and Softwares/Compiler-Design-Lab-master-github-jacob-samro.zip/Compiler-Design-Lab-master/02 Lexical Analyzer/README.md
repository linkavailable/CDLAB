Steps to compile
```
gcc lexicalanalyzer.cpp
./a.out
```
