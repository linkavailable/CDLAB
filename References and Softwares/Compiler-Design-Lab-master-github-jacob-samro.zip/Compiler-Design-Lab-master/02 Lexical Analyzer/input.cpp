#include <iostream> 

int main(){ 
int a=10,c = a+ 10;
char x;
float x1,x2;

}
