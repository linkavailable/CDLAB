Steps to compile

```
g++ symboltable.cpp
./a.out
```
