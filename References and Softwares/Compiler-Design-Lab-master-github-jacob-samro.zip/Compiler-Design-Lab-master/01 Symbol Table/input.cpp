#include <iostream> 

int main(){ 
int a,b,c;
char x;
float x1,x2;

}
